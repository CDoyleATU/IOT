![Pushsafer](https://www.pushsafer.com/de/assets/logos/logo.png)

Send [pushsafer.com](https://www.pushsafer.com) notifications from your Arduino

Download: [https://github.com/appzer/pushsafer-arduino-library/](https://github.com/appzer/pushsafer-arduino-library/)

Pushsafer make it easy and safe to get push-notifications in real time on your
- Android device
- iOS device (incl. iPhone, iPad, iPod Touch)
- Windows Phone & Desktop
- Browser (Chrome & Firefox)


# pushsafer-arduino-library
Send pushsafer.com messages from the arduino to your Browser, Android, iOS or Windows device.

[Here is an working example!](https://github.com/appzer/pushsafer-arduino-library/blob/master/examples/esp8266/sendEvent/sendEvent.ino)

forked from [witnessmenow](https://github.com/witnessmenow) ... thanks a lot!
